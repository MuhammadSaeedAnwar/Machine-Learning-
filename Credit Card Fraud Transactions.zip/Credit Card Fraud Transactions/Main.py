import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from statsmodels.tsa.arima.model import ARIMA
import joblib
import matplotlib.pyplot as plt

data = pd.read_csv('datacamp_workspace_export.csv')

data = data.dropna(subset=['is_fraud'])

numeric_columns = ['lat', 'long', 'city_pop', 'merch_lat', 'merch_long']
X_cls = data[numeric_columns]
X_reg = data[numeric_columns]
y_class = data['is_fraud']
y_amount = data['amt']

X_train_cls, X_test_cls, y_train_cls, y_test_cls = train_test_split(X_cls, y_class, test_size=0.2, random_state=42, stratify=y_class)

scaler_cls = StandardScaler()
X_train_cls = scaler_cls.fit_transform(X_train_cls)
X_test_cls = scaler_cls.transform(X_test_cls)

rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

rf_classifier.fit(X_train_cls, y_train_cls)

y_pred_cls = rf_classifier.predict(X_test_cls)

accuracy_cls = accuracy_score(y_test_cls, y_pred_cls)
conf_matrix_cls = confusion_matrix(y_test_cls, y_pred_cls)
class_report_cls = classification_report(y_test_cls, y_pred_cls)

print(f'Classification Accuracy: {accuracy_cls}')
print(f'Confusion Matrix:\n{conf_matrix_cls}')
print(f'Classification Report:\n{class_report_cls}')

# Plotting the features
feature_importances = rf_classifier.feature_importances_
plt.figure(figsize=(10, 6))
plt.barh(range(len(numeric_columns)), feature_importances, align='center')
plt.yticks(range(len(numeric_columns)), numeric_columns)
plt.xlabel('Feature Importance')
plt.title('Feature Importance for Classification (Random Forest)')
plt.show





